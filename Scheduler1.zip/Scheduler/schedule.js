$(document).ready(function() {$('.dropdown-item').click(function() {var dropDownValue = $(this).text();
      if (dropDownValue === "Daily") {$('#timer').show();$('.verify').show();} else{
        $('#timer').show();$('#WeekDaySelection').show();$('.verify').show();}
    });
  
    $('#selectall').click(function() {var isChecked = $(this).prop('checked');$('input[name="check"]').prop('checked', isChecked);
    });
  
    $('input[name="check"]').click(function() {var allBoxes = $('input[name="check"]'),selectAllCheck = $('#selectall');
      if (allBoxes.length === allBoxes.filter(':checked').length) {selectAllCheck.prop('checked', true);} else {
        selectAllCheck.prop('checked', false);}});
// time add function
$('.addtime').click(function(){
var timeappend = '<div class="div_timer"><input type="time" name="settime"><button type="button" class="btn-close" aria-label="Close"></button><br></div>';
var closeBtn = $('input[name="closebtn"]');
$('#timer').append('<br>',timeappend);
$('.btn-close').click(function(){
  $(this).closest('.div_timer').remove(); 
});
})
$('#liveToastBtn').click(function(){
  $('.pop_up').fadeIn(100);
  $('.pop_up').fadeOut(2000);
})
$('#liveToastBtn1').click(function(){
  location.reload();
})
  });

  