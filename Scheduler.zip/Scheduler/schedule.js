

// // Hide and show Script
// $('#dropDownSelect').click(function() {
//     var dropDownValue = $('.dropdown-item').text();
    
//     if (dropDownValue === "Daily") {
//       $('#timer').hide();
//       $('#dropdown').show();
//     } else {
//       $('#timer').show();
//       $('#dropdown').hide();
//     }
//   });
  

// // WeekDay Selection script
// $('#selectall').click(function() {
//     var isChecked = $(this).prop('checked');
//     $('input[name="check"]').prop('checked', isChecked);
//   });
//   $('input[name ="check"]').click(function(){
// var allboxes =  $('input[name ="check"]') , selectallcheck = $('#selectall') ;
//  if (allboxes.length === allboxes.filter(':checked').length)
//  {
// selectallcheck.prop('checked',true);
//  }
// else{
//     selectallcheck.prop('checked',false);
// }
//   });
$(document).ready(function() {
    $('.dropdown-item').click(function() {
      var dropDownValue = $(this).text();
      if (dropDownValue === "Daily") {
        $('#timer').hide();
        $('#WeekDaySelection').show();
      } else {
        $('#timer').show();
        $('#WeekDaySelection').hide();
      }
    });
  
    $('#selectall').click(function() {
      var isChecked = $(this).prop('checked');
      $('input[name="check"]').prop('checked', isChecked);
    });
  
    $('input[name="check"]').click(function() {
      var allBoxes = $('input[name="check"]'),
          selectAllCheck = $('#selectall');
  
      if (allBoxes.length === allBoxes.filter(':checked').length) {
        selectAllCheck.prop('checked', true);
      } else {
        selectAllCheck.prop('checked', false);
      }
    });
// time add function
$('.addtime').click(function(){
var timeappend = '<input type="time" name="settime"><button type="button" class="btn-close" aria-label="Close"></button><br>';
var closeBtn = $('input[name="closebtn"]');
$('#timer').append(timeappend);
$('.btn-close').click(function(){
  $('timeappend').remove();
})
})

  });
  